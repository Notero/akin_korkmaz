package com.example.xrpw;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WalletAdapter extends RecyclerView.Adapter<WalletAdapter.WalletViewHolder> {

    public interface OnWalletClickListener {
        void onWalletClick(Wallet wallet);
    }

    private final List<Wallet> wallets;
    private final OnWalletClickListener listener;

    public WalletAdapter(List<Wallet> wallets, OnWalletClickListener listener) {
        this.wallets = wallets;
        this.listener = listener;
    }

    @NonNull
    @Override
    public WalletViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.wallet, parent, false);
        return new WalletViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull WalletViewHolder holder, int position) {
        final Wallet wallet = wallets.get(position);
        holder.tvWalletTitle.setText(wallet.getName());
        holder.tvWalletKeys.setText(wallet.getKeys());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onWalletClick(wallet);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return wallets != null ? wallets.size() : 0;
    }

    static class WalletViewHolder extends RecyclerView.ViewHolder {

        TextView tvWalletTitle;
        TextView tvWalletKeys;

        public WalletViewHolder(@NonNull View itemView) {
            super(itemView);
            tvWalletTitle = itemView.findViewById(R.id.tvWalletTitle);
            tvWalletKeys = itemView.findViewById(R.id.tvWalletKeys);
        }
    }
}
