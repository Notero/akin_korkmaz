package com.example.xrpw;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class WalletDetailActivity extends AppCompatActivity {

    public static final String EXTRA_WALLET = "extra_wallet";

    private TextView tvWalletTitle;
    private TextView tvWalletKeys;
    private EditText etRenameWallet;
    private Button btnRenameWallet;
    private RecyclerView rvPayments;

    private Wallet wallet;
    private PaymentAdapter paymentAdapter;
    private final List<Payment> payments = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.wallet_detail);

        // From included wallet card
        tvWalletTitle = findViewById(R.id.tvWalletTitle);
        tvWalletKeys = findViewById(R.id.tvWalletKeys);

        etRenameWallet = findViewById(R.id.etRenameWallet);
        btnRenameWallet = findViewById(R.id.btnRenameWallet);
        rvPayments = findViewById(R.id.rvPayments);

        wallet = (Wallet) getIntent().getSerializableExtra(EXTRA_WALLET);
        if (wallet == null) {
            wallet = new Wallet("Unknown Wallet", "No keys");
        }

        tvWalletTitle.setText(wallet.getName());
        tvWalletKeys.setText(wallet.getKeys());

        setupDummyPayments();

        paymentAdapter = new PaymentAdapter(payments);
        rvPayments.setLayoutManager(new LinearLayoutManager(this));
        rvPayments.setAdapter(paymentAdapter);

        btnRenameWallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                renameWallet();
            }
        });
    }

    private void renameWallet() {
        String newName = etRenameWallet.getText().toString().trim();
        if (TextUtils.isEmpty(newName)) {
            Toast.makeText(this, "Enter new wallet name", Toast.LENGTH_SHORT).show();
            return;
        }
        wallet.setName(newName);
        tvWalletTitle.setText(newName);
        // TODO: persist new name
    }

    private void setupDummyPayments() {
        payments.clear();
        payments.add(new Payment("+ 10.5 XRP", "To: rDEST...", "2025-11-21 · memo text"));
        payments.add(new Payment("- 2.0 XRP", "To: rSHOP...", "2025-11-20 · groceries"));
        payments.add(new Payment("+ 50 XRP", "From: rFRIEND...", "2025-11-19 · payback"));
    }
}
