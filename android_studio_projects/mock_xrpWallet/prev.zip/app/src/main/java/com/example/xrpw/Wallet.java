package com.example.xrpw;
import java.io.Serializable;

public class Wallet implements Serializable {

    private String name;
    private String keys; // could hold address / pubkey / seed in simple multiline text

    public Wallet(String name, String keys) {
        this.name = name;
        this.keys = keys;
    }

    public String getName() {
        return name;
    }

    public String getKeys() {
        return keys;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setKeys(String keys) {
        this.keys = keys;
    }
}
