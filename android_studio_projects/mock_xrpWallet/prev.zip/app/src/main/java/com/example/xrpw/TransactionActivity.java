package com.example.xrpw;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class TransactionActivity extends AppCompatActivity {

    private EditText etAmount;
    private EditText etDestination;
    private EditText etMemo;
    private Button btnSubmitTransaction;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.transaction);

        etAmount = findViewById(R.id.etAmount);
        etDestination = findViewById(R.id.etDestination);
        etMemo = findViewById(R.id.etMemo);
        btnSubmitTransaction = findViewById(R.id.btnSubmitTransaction);

        btnSubmitTransaction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitTransaction();
            }
        });
    }

    private void submitTransaction() {
        String amount = etAmount.getText().toString().trim();
        String dest = etDestination.getText().toString().trim();
        String memo = etMemo.getText().toString().trim();

        if (TextUtils.isEmpty(amount) || TextUtils.isEmpty(dest)) {
            Toast.makeText(this, "Amount and destination required", Toast.LENGTH_SHORT).show();
            return;
        }

        // TODO: send transaction via XRPL / backend
        Toast.makeText(this,
                "Submitting txn: " + amount + " to " + dest + " (dummy)",
                Toast.LENGTH_SHORT).show();
    }
}
