package com.example.xrpw;

public class Payment {

    private final String amountText;
    private final String destinationText;
    private final String dateText;

    public Payment(String amountText, String destinationText, String dateText) {
        this.amountText = amountText;
        this.destinationText = destinationText;
        this.dateText = dateText;
    }

    public String getAmountText() {
        return amountText;
    }

    public String getDestinationText() {
        return destinationText;
    }

    public String getDateText() {
        return dateText;
    }
}
