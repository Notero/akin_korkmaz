package com.example.xrpw;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements WalletAdapter.OnWalletClickListener {

    private RecyclerView rvWallets;
    private Button btnAddWallet;
    private Button btnMakePayment;
    private WalletAdapter walletAdapter;
    private final List<Wallet> walletList = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvWallets = findViewById(R.id.rvWallets);
        btnAddWallet = findViewById(R.id.btnAddWallet);
        btnMakePayment = findViewById(R.id.btnMakePayment);

        setupDummyWallets(); // TODO: replace with real storage / backend

        walletAdapter = new WalletAdapter(walletList, this);
        rvWallets.setLayoutManager(new LinearLayoutManager(this));
        rvWallets.setAdapter(walletAdapter);

        btnAddWallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, CreateAddWalletActivity.class);
                startActivity(i);
            }
        });

        btnMakePayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, TransactionActivity.class);
                startActivity(i);
            }
        });
    }

    private void setupDummyWallets() {
        walletList.clear();
        walletList.add(new Wallet("Wallet 1", "rEXAMPLE1...\nPUBKEY1\nSEED1"));
        walletList.add(new Wallet("Wallet 2", "rEXAMPLE2...\nPUBKEY2\nSEED2"));
        walletList.add(new Wallet("Wallet 3", "rEXAMPLE3...\nPUBKEY3\nSEED3"));
    }

    @Override
    public void onWalletClick(Wallet wallet) {
        Intent i = new Intent(this, WalletDetailActivity.class);
        i.putExtra(WalletDetailActivity.EXTRA_WALLET, wallet);
        startActivity(i);
    }
}
