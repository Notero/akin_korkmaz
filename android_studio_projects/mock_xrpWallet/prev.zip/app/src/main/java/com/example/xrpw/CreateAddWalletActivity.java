package com.example.xrpw;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class CreateAddWalletActivity extends AppCompatActivity {

    private Button btnAddExistingWallet;
    private Button btnGenerateNewWallet;
    private EditText etSecretKey;
    private EditText etSecretSeed;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_add_wallet);

        btnAddExistingWallet = findViewById(R.id.btnAddExistingWallet);
        btnGenerateNewWallet = findViewById(R.id.btnGenerateNewWallet);
        etSecretKey = findViewById(R.id.etSecretKey);
        etSecretSeed = findViewById(R.id.etSecretSeed);

        btnAddExistingWallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addExistingWallet();
            }
        });

        btnGenerateNewWallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                generateNewWallet();
            }
        });
    }

    private void addExistingWallet() {
        String key = etSecretKey.getText().toString().trim();
        String seed = etSecretSeed.getText().toString().trim();

        if (TextUtils.isEmpty(key) || TextUtils.isEmpty(seed)) {
            Toast.makeText(this, "Enter secret key and seed", Toast.LENGTH_SHORT).show();
            return;
        }

        // TODO: Validate, store wallet, and return to MainActivity / backend
        Toast.makeText(this, "Existing wallet added (dummy)", Toast.LENGTH_SHORT).show();
    }

    private void generateNewWallet() {
        // TODO: Call XRPL / backend to generate real wallet
        Toast.makeText(this, "Generate New Wallet clicked (dummy)", Toast.LENGTH_SHORT).show();
    }
}
