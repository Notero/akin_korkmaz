package com.example.xrpw;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PaymentAdapter extends RecyclerView.Adapter<PaymentAdapter.PaymentViewHolder> {

    private final List<Payment> payments;

    public PaymentAdapter(List<Payment> payments) {
        this.payments = payments;
    }

    @NonNull
    @Override
    public PaymentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_payment, parent, false);
        return new PaymentViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull PaymentViewHolder holder, int position) {
        Payment p = payments.get(position);
        holder.tvPaymentAmount.setText(p.getAmountText());
        holder.tvPaymentDestination.setText(p.getDestinationText());
        holder.tvPaymentDate.setText(p.getDateText());
    }

    @Override
    public int getItemCount() {
        return payments != null ? payments.size() : 0;
    }

    static class PaymentViewHolder extends RecyclerView.ViewHolder {

        TextView tvPaymentAmount;
        TextView tvPaymentDestination;
        TextView tvPaymentDate;

        public PaymentViewHolder(@NonNull View itemView) {
            super(itemView);
            tvPaymentAmount = itemView.findViewById(R.id.tvPaymentAmount);
            tvPaymentDestination = itemView.findViewById(R.id.tvPaymentDestination);
            tvPaymentDate = itemView.findViewById(R.id.tvPaymentDate);
        }
    }
}
